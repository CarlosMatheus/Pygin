class Global:
    current_score = 0
    difficulty = 0
