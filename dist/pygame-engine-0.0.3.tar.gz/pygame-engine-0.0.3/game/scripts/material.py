# class Material:
#
#     def __init__(self, color, alpha=None):
#         self.color = color
#         self.alpha = alpha
