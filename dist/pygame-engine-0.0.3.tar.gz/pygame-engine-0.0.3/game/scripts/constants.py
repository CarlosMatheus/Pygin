class Constants:
    screen_width = 360
    screen_height = 640
    circCenter_x = 180
    circCenter_y = 520
    circRadius = 95
    current_score = 0