class Component:

    def __init__(self, game_object):
        self.game_object = game_object
        self.transform = game_object.transform
